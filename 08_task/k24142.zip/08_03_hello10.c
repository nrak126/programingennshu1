#include <stdio.h>

int main(int argc, const char* argv[]) {
  int count = 0;

  while (count < 10) {
    printf("Hello, World!\n");
    count++;
  }

  return 0;
}
